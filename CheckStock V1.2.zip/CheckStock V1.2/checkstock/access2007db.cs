﻿using System;
using System.Windows.Forms;
//using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.IO;            //--- Add for use with DB ---------                            
using System.Data;          //--- Add for use with DB --------- 
using System.Data.OleDb;    //--- Add for use with DB ---------     

namespace checkstock
{
    public class access2007db
    {
        private static OleDbConnection GetConnection()
        {
            OleDbConnection conn = new OleDbConnection();
            try
            {
                string constr = "Provider = Microsoft.ACE.OLEDB.12.0; data source="+Application.StartupPath+"\\Check.accdb";
                conn = new OleDbConnection(constr);
                conn.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Data Base Connection Error");
            }

            return conn;
        }
        //----------------------------------------------------------------------------------------------------------------
        private static void CloseConnection(OleDbConnection conn)
        {
            try
            {
                conn.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Database Connection Clossing Error");
            }
        }
        //----------------------------------------------------------------------------------------------------------------
        public void ExcuteSql(string strSql)
        {
            try
            {
                OleDbConnection conn = GetConnection();
                OleDbCommand Cmd = new OleDbCommand(strSql, conn);
                Cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception ex) { MessageBox.Show("Have Sn In stock!!"); }

        }
        //----------------------------------------------------------------------------------------------------------------
        public DataTable FillDataGrid(string strSql)
        {
            DataSet ds = new DataSet();
            OleDbConnection conn = GetConnection();
            OleDbDataAdapter da = new OleDbDataAdapter(strSql, conn);
            da.Fill(ds);
            conn.Close();
            DataTable dt = ds.Tables[0];
            return dt;
        }
        //----------------------------------------------------------------------------------------------------------------
        public string ExcuteDataReaderOneField(string sqlcmd, int returnfield)
        {
            string QueryResults = "";

            OleDbConnection conn = GetConnection();
            OleDbCommand Cmd = new OleDbCommand(sqlcmd, conn);
            try
            {
                // Create data reader
                OleDbDataReader rdr = Cmd.ExecuteReader();
                while (rdr.Read())
                {
                    QueryResults = rdr[returnfield].ToString();
                }
                rdr.Close();

            }
            catch
            {
                MessageBox.Show("Error On Data reader");
            }
            finally
            {
                conn.Close();
            }
            return QueryResults;

        }
        //----------------------------------------------------------------------------------------------------------------
        public string ExcuteDataReaderAllField(string sqlcmd)
        {
            string QueryResults = "";

            OleDbConnection conn = GetConnection();
            OleDbCommand Cmd = new OleDbCommand(sqlcmd, conn);
            try
            {
                // Create data reader
                OleDbDataReader rdr = Cmd.ExecuteReader();
                int fieldQty = rdr.FieldCount;

                while (rdr.Read())
                {
                    for (int i = 0; i < fieldQty; i++)
                    {
                        QueryResults += rdr[i].ToString() + ",";
                    }

                }
                rdr.Close();

            }
            catch
            {
                MessageBox.Show("Error On Data reader");
            }
            finally
            {
                conn.Close();
            }
            return QueryResults;

        }
        //----------------------------------------------------------------------------------------------------------------
        public int QueryAndCount(string sqlcmd)
        {
            int countQty = 0;
            string QueryResults = "";
            OleDbConnection conn = GetConnection();
            OleDbCommand Cmd = new OleDbCommand(sqlcmd, conn);
            try
            {
                // Create data reader
                OleDbDataReader rdr = Cmd.ExecuteReader();


                while (rdr.Read())
                {
                    QueryResults += rdr[1].ToString() + ",";

                }
                rdr.Close();

            }
            catch
            {
                // MessageBox.Show("Error On Data reader");
                countQty = 0;
            }
            finally
            {
                conn.Close();
            }
            string[] arStr = QueryResults.Split(',');
            countQty = arStr.Length - 1;
            return countQty;

        }
        //----------------------------------------------------------------------------------------------------------------

    }
}
