﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Odbc;
using System.Data;

namespace checkstock
{
    
    class OracleODBC
    {
        OdbcConnection conn = new OdbcConnection();
       
        DataSet DS = new DataSet();
       
        string sConnString = "Driver={Microsoft ODBC for Oracle};Server=CSPD;Uid=L2QC1;Pwd=L2QC1";

        public OracleODBC() 
        {
            this.conn = new OdbcConnection(sConnString);
           
            this.conn.Open();
        }
       
        public string GetSerialNumber(string SN)
        {
            OdbcCommand odbcc = new OdbcCommand();
            odbcc.CommandText = "SELECT * FROM TMCP.VDQC891_BAL_PDA  WHERE VDQC891_BAL_PDA.LINE_NO = '" + "G3" + "'";
            odbcc.Connection = conn;
            OdbcDataAdapter odbca = new OdbcDataAdapter(odbcc);
            DS.Clear();
            odbca.Fill(DS);
            
            if (DS.Tables[0].Rows.Count != 0)
                return DS.Tables[0].Rows[0][0].ToString();
            else
                return "FAIL";
        }

        public DataTable QueryOracleData(string SqlCmd)
        {
            OdbcCommand odbcc = new OdbcCommand();
           // odbcc.CommandText = "SELECT * FROM TMCP.VDQC891_BAL_PDA VDQC891_BAL_PDA WHERE VDQC891_BAL_PDA.LINE_NO = '" + "G3" + "'";
            odbcc.CommandText = SqlCmd;
            odbcc.Connection = conn;
            OdbcDataAdapter odbca = new OdbcDataAdapter(odbcc);
            DS.Clear();
           
            odbca.Fill(DS);

            return DS.Tables[0];
           
        }
       
        public DataTable GetIcLot88A(string PcbaSn)
        {
            OdbcCommand odbcc = new OdbcCommand();
            odbcc.CommandText = "select * from TMCP.WQCFT88A where MO_SN = '" + PcbaSn + "'";
            odbcc.Connection = conn;
            OdbcDataAdapter odbca = new OdbcDataAdapter(odbcc);
            DS.Clear();

            odbca.Fill(DS);

            return DS.Tables[0];
        }
        public DataTable GetIcLot88B(string PcbaSn)
        {
            OdbcCommand odbcc = new OdbcCommand();
            odbcc.CommandText = "select * from TMCP.WQCFT88B where MO_SN = '" + PcbaSn + "'";
            odbcc.Connection = conn;
            OdbcDataAdapter odbca = new OdbcDataAdapter(odbcc);
            DS.Clear();

            odbca.Fill(DS);

            return DS.Tables[0];
        }
        public DataTable GetIcLot88C(string PcbaSn)
        {
            OdbcCommand odbcc = new OdbcCommand();
            odbcc.CommandText = "select * from TMCP.WQCFT88C where MO_SN = '" + PcbaSn + "'";
            odbcc.Connection = conn;
            OdbcDataAdapter odbca = new OdbcDataAdapter(odbcc);
            DS.Clear();

            odbca.Fill(DS);

            return DS.Tables[0];
        }
        public DataTable GetDqc34(string PcbaSn)
        {
            OdbcCommand odbcc = new OdbcCommand();
            odbcc.CommandText = "select * from TMCP.DQC34 where MO_SN = '" + PcbaSn + "'";
            odbcc.Connection = conn;
            OdbcDataAdapter odbca = new OdbcDataAdapter(odbcc);
            DS.Clear();

            odbca.Fill(DS);

            return DS.Tables[0];
        }
        public DataTable GetPcbaTest(string PcbaSn)
        {
            OdbcCommand odbcc = new OdbcCommand();
            odbcc.CommandText = "select * from TMCP.PCBA_TEST where SERIAL_NO = '" + PcbaSn + "' order by TIMESTAMP2";
            odbcc.Connection = conn;
            OdbcDataAdapter odbca = new OdbcDataAdapter(odbcc);
            DS.Clear();

            odbca.Fill(DS);

            return DS.Tables[0];
        }
        public DataTable QueryDataTable(string SqlCmdIn)
        {
            OdbcCommand odbcc = new OdbcCommand();
            odbcc.CommandText = SqlCmdIn;
            odbcc.Connection = conn;
            OdbcDataAdapter odbca = new OdbcDataAdapter(odbcc);
            DS.Clear();

            odbca.Fill(DS);

            return DS.Tables[0];
        }
    }
}
