﻿namespace checkstock
{
    partial class Random
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Random));
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnxxx = new System.Windows.Forms.Button();
            this.txtcreate = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnlog = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtempid = new System.Windows.Forms.TextBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnoff = new System.Windows.Forms.Button();
            this.btnon = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.dgvquery = new System.Windows.Forms.DataGridView();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvquery)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox4.Controls.Add(this.btnxxx);
            this.groupBox4.Controls.Add(this.txtcreate);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(25, 158);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(389, 109);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Create Event ID";
            // 
            // btnxxx
            // 
            this.btnxxx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnxxx.BackColor = System.Drawing.Color.Transparent;
            this.btnxxx.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnxxx.FlatAppearance.BorderSize = 2;
            this.btnxxx.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnxxx.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btnxxx.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnxxx.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnxxx.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnxxx.Location = new System.Drawing.Point(287, 37);
            this.btnxxx.Margin = new System.Windows.Forms.Padding(0);
            this.btnxxx.Name = "btnxxx";
            this.btnxxx.Size = new System.Drawing.Size(67, 37);
            this.btnxxx.TabIndex = 7;
            this.btnxxx.Text = "Create";
            this.btnxxx.UseVisualStyleBackColor = false;
            this.btnxxx.Click += new System.EventHandler(this.btnxxx_Click_1);
            // 
            // txtcreate
            // 
            this.txtcreate.Enabled = false;
            this.txtcreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcreate.Location = new System.Drawing.Point(50, 44);
            this.txtcreate.Name = "txtcreate";
            this.txtcreate.Size = new System.Drawing.Size(148, 22);
            this.txtcreate.TabIndex = 6;
            this.txtcreate.TextChanged += new System.EventHandler(this.txtcreate_TextChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox3.Controls.Add(this.btnlog);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txtempid);
            this.groupBox3.Controls.Add(this.txtpassword);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(25, 26);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(389, 109);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Log-IN";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // btnlog
            // 
            this.btnlog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnlog.BackColor = System.Drawing.Color.Transparent;
            this.btnlog.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnlog.FlatAppearance.BorderSize = 2;
            this.btnlog.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnlog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btnlog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlog.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnlog.Location = new System.Drawing.Point(310, 48);
            this.btnlog.Margin = new System.Windows.Forms.Padding(0);
            this.btnlog.Name = "btnlog";
            this.btnlog.Size = new System.Drawing.Size(53, 28);
            this.btnlog.TabIndex = 7;
            this.btnlog.Text = "Log";
            this.btnlog.UseVisualStyleBackColor = false;
            this.btnlog.Click += new System.EventHandler(this.btnlog_Click);
            this.btnlog.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnlog_KeyPress);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(50, 5, 50, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Emp ID";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 73);
            this.label2.Margin = new System.Windows.Forms.Padding(50, 5, 50, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Password";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtempid
            // 
            this.txtempid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtempid.Location = new System.Drawing.Point(141, 30);
            this.txtempid.Name = "txtempid";
            this.txtempid.Size = new System.Drawing.Size(121, 22);
            this.txtempid.TabIndex = 0;
            this.txtempid.TextChanged += new System.EventHandler(this.txtempid_TextChanged);
            // 
            // txtpassword
            // 
            this.txtpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.Location = new System.Drawing.Point(141, 71);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.PasswordChar = '*';
            this.txtpassword.Size = new System.Drawing.Size(121, 22);
            this.txtpassword.TabIndex = 0;
            this.txtpassword.TextChanged += new System.EventHandler(this.txtpassword_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.btnoff);
            this.groupBox1.Controls.Add(this.btnon);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(25, 305);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(389, 109);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Off-On Event";
            // 
            // btnoff
            // 
            this.btnoff.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnoff.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnoff.Enabled = false;
            this.btnoff.FlatAppearance.BorderSize = 2;
            this.btnoff.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btnoff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnoff.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnoff.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnoff.Location = new System.Drawing.Point(313, 67);
            this.btnoff.Margin = new System.Windows.Forms.Padding(0);
            this.btnoff.Name = "btnoff";
            this.btnoff.Size = new System.Drawing.Size(41, 31);
            this.btnoff.TabIndex = 7;
            this.btnoff.Text = "Off";
            this.btnoff.UseVisualStyleBackColor = false;
            this.btnoff.Click += new System.EventHandler(this.btnoff_Click);
            // 
            // btnon
            // 
            this.btnon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnon.Enabled = false;
            this.btnon.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnon.FlatAppearance.BorderSize = 2;
            this.btnon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btnon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnon.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnon.Location = new System.Drawing.Point(313, 26);
            this.btnon.Margin = new System.Windows.Forms.Padding(0);
            this.btnon.Name = "btnon";
            this.btnon.Size = new System.Drawing.Size(41, 31);
            this.btnon.TabIndex = 7;
            this.btnon.Text = "On";
            this.btnon.UseVisualStyleBackColor = false;
            this.btnon.Click += new System.EventHandler(this.btnon_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Blue;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Lavender;
            this.label3.Location = new System.Drawing.Point(42, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 37);
            this.label3.TabIndex = 0;
            this.label3.Text = "No Event";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // dgvquery
            // 
            this.dgvquery.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvquery.Location = new System.Drawing.Point(464, 26);
            this.dgvquery.Name = "dgvquery";
            this.dgvquery.Size = new System.Drawing.Size(42, 109);
            this.dgvquery.TabIndex = 11;
            this.dgvquery.Visible = false;
            // 
            // Random
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(443, 444);
            this.Controls.Add(this.dgvquery);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Random";
            this.Text = "Random";
            this.Load += new System.EventHandler(this.Random_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvquery)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnxxx;
        private System.Windows.Forms.TextBox txtcreate;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtempid;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnoff;
        private System.Windows.Forms.Button btnon;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.DataGridView dgvquery;
        private System.Windows.Forms.Button btnlog;


    }
}