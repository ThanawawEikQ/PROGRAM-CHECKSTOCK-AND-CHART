﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LiveCharts.Wpf;
using LiveCharts;
using static checkstock.DataBar;
using LiveCharts.Configurations;
using System.Windows;
using MessageBox = System.Windows.Forms.MessageBox;
using System.Runtime.Serialization;
using LiveCharts.Helpers;

namespace checkstock
{
    public partial class PageChart : UserControl
    {
        public PageChart()
        {
            InitializeComponent();
            AutoQ();

        }
        string waitID = "";
        List<int> ValuesTb = new List<int>();
        List<string> MODELVL = new List<string>();
        List<int> ValuesModel = new List<int>();
        string[] Tb = { "AOI", "ICT", "RTS", "PACKING", "WAIT CATTON", "QA", "X-RAY", "REPAIR", "BARCODE", "ETC" };
        List<string> MODEL = new List<string>();

        public ChartValues<string> ResultsLabel2 { get; set; }
        public ChartValues<string> ResultsLabel1 { get; set; }


        private void query()      // Get ID
        {
            try
            {
                access2007db db = new access2007db();
                DataTable dt = new DataTable();
                string sql = "select * from random Where Status = 'on' and DateTimes order by DateTimes DESC ";
                dt = db.FillDataGrid(sql);
                dgvquery.DataSource = dt;
                if (dgvquery.RowCount >= 2)
                {
                    waitID = dgvquery.Rows[0].Cells["IDeven"].Value.ToString();
                    //  MessageBox.Show(waitID);

                }
            }
            catch
            {
            }
        }


        private void AutoQ()
        {
            try
            {
                ValuesTb.Clear();

                query();
                int GetCount = 0;
                string GetTotal = "";
                string TB = "AOI,ICT,RTS,PACKING,WAIRCARTON,QA,X-RAY,REPAIR,BARCODE,ETC";
                string[] arr = TB.Split(',');
                for (int i = 0; i < arr.Length; i++)
                {
                    string GetTb = arr[i];
                    int GetValues = QueryData(waitID, GetTb);
                    string Total = GetTb + "," + GetValues;
                    ValuesTb.Add(GetValues);
                }
            
                GetChart(); // Show Chart
            }
            catch (Exception ex)
            { //MessageBox.Show(ex.Message);
            }
        }
        private int QueryData(string IDe, string Sta)
        {
            string Sql = "SELECT Count(*) FROM checkstock WHERE IDeven ='" + IDe + "' AND STATION ='" + Sta + "'";
            access2007db db = new access2007db();
            DataTable dt = new DataTable();
            dt = db.FillDataGrid(Sql);
            dataGridView1.DataSource = dt;
            int GetCount = 0;
            int Getc = dataGridView1.Rows.Count;
            // MessageBox.Show(Getc.ToString());
            if (dataGridView1.Rows.Count >= 1)
            {
                GetCount = int.Parse(dataGridView1.Rows[0].Cells[0].Value.ToString());
            }
            return GetCount;
        }

        private void GetChart()
        {
            MODEL.AddRange(Tb);
            cartesianChart1.Series.Clear();
            ResultsLabel2 = MODEL.AsChartValues();

             ColumnSeries series1 = new ColumnSeries()
            {
                Title = "",
                Values = ValuesTb.AsChartValues(),

            };

            Axis axisX = new Axis()
            {
                FontSize = 12,
                Separator = new Separator() { Step = 1, IsEnabled = false },
                Labels = ResultsLabel2,
                ShowLabels = true,

            };

            Axis axisY = new Axis()
            {

                LabelFormatter = value => value.ToString("0" + "Qty"),

            };
            
            cartesianChart1.Series.Add(series1);
            cartesianChart1.AxisX.Add(axisX);
            cartesianChart1.AxisY.Add(axisY);
            cartesianChart1.Update();
            cartesianChart1.Refresh();
        }

        private void PageChart_Load(object sender, EventArgs e)
        {
            this.Dock = DockStyle.Fill;
        }


        //------------------------------------------------------------------------------------------------------------------------
        private void cartesianChart1_DataClick(object sender, ChartPoint chartPoint)     // Step Check  DataClick  1
        {
            tableLayoutPanel4.ColumnStyles[0].Width = 5F;
            string Get = Convert.ToString(chartPoint.X);
            GetTbDataClick(Get);
        }
        private void GetTbDataClick(string Data)  // Step  Check  DataClick     2
        {
            try
            {
                string DataIn = "";
                string[] Labels = { "AOI", "ICT", "RTS", "PACKING", "WAIT CATTON", "QA", "X-RAY", "REPAIR", "BARCODE", "ETC" };

                if (Data == "0") { DataIn = "AOI"; }
                else if (Data == "1") { DataIn = "ICT"; }
                else if (Data == "2") { DataIn = "RTS"; }
                else if (Data == "3") { DataIn = "PACKING"; }
                else if (Data == "4") { DataIn = "WAIT CATTON"; }
                else if (Data == "5") { DataIn = "QA"; }
                else if (Data == "6") { DataIn = "X-RAY"; }
                else if (Data == "7") { DataIn = "REPAIR"; }
                else if (Data == "8") { DataIn = "BARCODE"; }
                else if (Data == "9") { DataIn = "ETC"; }
               // MessageBox.Show(DataIn);
                GetQuery(DataIn); // Check Model for Tb
            }
            catch { }

        }

        private void GetQuery(string Tb)   // Step  Check  DataClick     3
        {
            try
            {
                MODELVL.Clear();
                ValuesModel.Clear();

                access2007db db = new access2007db();
                DataTable dt = new DataTable();
                string Sql = "SELECT DISTINCT MODEL FROM checkstock WHERE IDeven ='" + waitID + "' AND STATION = '" + Tb + "' ";
                dt = db.FillDataGrid(Sql);
                dataGridView1.DataSource = dt;
                int CountRow = dataGridView1.RowCount - 1;
                string GetModel = "";
                if (CountRow > 0)
                {
                    for (int i = 0; i < CountRow; i++)  // Get  Model  To string
                    {
                        GetModel = dataGridView1.Rows[i].Cells["MODEL"].Value.ToString();
                        MODELVL.Add(GetModel);   //add Model To list
                       // MessageBox.Show(GetModel);
                    }
                }

                //-----------------------------------------------

                for (int y = 0; y < MODELVL.Count; y++)        // Step  Check  DataClick     4
                {
                    string Models = MODELVL[y];
                    int CountModel = ModelQuery(Tb, Models);
                    ValuesModel.Add(CountModel);           // ADd values Model 
                }
                GetChartAuto(); // SHOW CHART GO GO GO !
            }
            catch { }
        }
        private int ModelQuery(string Tb, string Model)     // Step  Check  DataClick     5 Query Count
        {

            access2007db dbs = new access2007db();
            DataTable dts = new DataTable();
            string Sqls = "SELECT Count(*)  FROM checkstock WHERE IDeven ='" + waitID + "' AND STATION = '" + Tb + "' AND MODEL ='" + Model + "'";
            dts = dbs.FillDataGrid(Sqls);
            dataGridView1.DataSource = dts;
            int MODEL = 0;
            if (dataGridView1.Rows.Count >= 1)
            {
                MODEL = int.Parse(dataGridView1.Rows[0].Cells[0].Value.ToString());
            }
            return MODEL;
        }
        //--------------------------------------------------------------------------------------------------------
        private void GetChartAuto()    // Chart Auto For DataClick
        {
            cartesianChart1.Series.Clear();
            
            cartesianChart1.AxisX.Clear();
            cartesianChart1.AxisY.Clear();
            ColumnSeries series1 = new ColumnSeries()
            {
                Title = "",
                Values = ValuesModel.AsChartValues(),
                

            };
            
            Axis axisX = new Axis()
            {

                Separator = new Separator() { Step = 1, IsEnabled = false },
                Labels = MODELVL.AsChartValues(),
                ShowLabels = true,
            };

            Axis axisY = new Axis()
            {

                LabelFormatter = value => value.ToString("0" + "Qty"),

            };
            
            cartesianChart1.Series.Add(series1);
            cartesianChart1.AxisX.Add(axisX);
            cartesianChart1.AxisY.Add(axisY);
            cartesianChart1.Update();
            cartesianChart1.Refresh();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
          
            cartesianChart1.AxisX.Clear();
            cartesianChart1.AxisY.Clear();
            tableLayoutPanel4.ColumnStyles[0].Width = 0F;
            AutoQ();

        }
    }
}
