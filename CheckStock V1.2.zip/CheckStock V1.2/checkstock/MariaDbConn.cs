﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Windows.Forms;

//----------------------------------------------------------------------------------------------------------------------------------------
using MySql.Data.MySqlClient;   //Need to add reference /Browse ==> MySqlData.dll file
//----------------------------------------------------------------------------------------------------------------------------------------

namespace checkstock
{
    class MariaDbConn
    {
      
        public DataTable QueryData(string SqlCmdIn)
        {

            string ConnString = "datasource=M21100400012002;database=WDSMT;port=3306;username=root;password=cal-comp9";      //1. Set database connection string

            MySqlConnection maRiaDbConn = new MySqlConnection(ConnString);      // 2. New mySql Connection object (use Database connection string as parameter)

            MySqlCommand myCmd = new MySqlCommand(SqlCmdIn, maRiaDbConn);       // 3. New mySql Command object (Use SqlCommand and mySqlConnection as parameter)

            // myCmd.CommandType = CommandType.Text;                               // Option ?

            MySqlDataAdapter myAdapter = new MySqlDataAdapter();                // ******

            myAdapter.SelectCommand = myCmd;                                    // ******                    

            DataTable myData = new DataTable();

            myAdapter.Fill(myData);

            //if (myData.Rows.Count > 0)
            //{
            //    //MessageBox.Show("Query to Read data from Maria DB Database OK", "QUERY DATA OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else
            //{
            //    MessageBox.Show("Query Data not found", "DATA NOT FOUND", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            return myData;
        }
        //--------------------------------------------------------------------------------------------------------------------------------------------
        public int InsertUpdateData(string SqlCmdIn)
        {
            int ReturnCode = 0;

            string ConnString = "datasource=10.5.125.166;database=wdsmt;port=3306;username=root;password=cal-comp9";      //1. Set database connection string

            MySqlConnection myConn = new MySqlConnection(ConnString);

            MySqlCommand myCmd = new MySqlCommand(SqlCmdIn, myConn);

            MySqlDataReader myReader;

            try
            {
                myConn.Open();

                myReader = myCmd.ExecuteReader();

                while (myReader.Read())
                {

                }

                myConn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("HAVE ID IN System !", "SYSTEM", MessageBoxButtons.OK, MessageBoxIcon.Information);  // ถ้า code Error จะเข้าฟังก์ชันนี้ จะโชวคำว่า  HAVE ID IN System ! //

                ReturnCode = 1; 
            }

            return ReturnCode;
        }
      
        
    }
}
