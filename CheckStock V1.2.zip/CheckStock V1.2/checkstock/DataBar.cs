﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace checkstock
{
    public class DataBar
    {
        public class TB : IComparable<TB>
        {
            public string name;
            public int Qty;

            public TB(string name, int Qty)
            {
                this.name = name;
                this.Qty = Qty;
            }

            public int CompareTo(TB emp)
            {
                if (emp == null)
                {
                    return 1;
                }

                return Comparer<int>.Default.Compare(this.Qty, emp.Qty);
            }

            public override string ToString()
            {
                return "[" + name + "," + Qty + "]";
            }
        }

    }

}
