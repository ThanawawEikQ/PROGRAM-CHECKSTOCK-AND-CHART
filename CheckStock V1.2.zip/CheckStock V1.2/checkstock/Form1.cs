﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Windows.Data;

namespace checkstock
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            GetUcon();
        }

      

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }


        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox1_Enter_1(object sender, EventArgs e)
        {

        }
        private void EMPIE()
        {
            try
            {
                int empid = txtempid.Text.Length;
                string f1 = txtempid.Text;
                f1 = f1.Substring(0, 1);  // เริ่มที่ 0 นับไป 1
                f1 = f1.ToUpper();
                if (empid == 7)
                {
                    if (f1 == "9" || f1 == "A" || f1 == "B" || f1 == "C") // กำหนดตัวอักษร
                    {
                        cbxstation.Enabled = true ;
                    }
                }
            }
            catch
            {
            }
        }

        private void txtpcb_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpcb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
              
                if (label5.Text == "No Event")
                {
                    MessageBox.Show("  Wait Event  ","System");
                }
                else
                {  
              
                     selectdata();
                   // information(); // Query Dqc31
                    txtpcb.Clear();
                }
            }
        }

        private void txtempid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                EMPIE();
                cbxstation.Focus();
            }
        }

        private void information()
        {
            try
            {
                string sn = txtpcb.Text;
                sn = sn.Substring(0, 6);
                sn = sn.ToUpper();
                OracleODBC db = new OracleODBC();
                DataTable dt = new DataTable();
                string sql = "select * from TMCP.DQC31 where MO_SN like '" + sn + "%'and rownum <= 10 ";
                dt = db.QueryDataTable(sql);
                dgvscanpcb.DataSource = dt;
                if (dt.Rows.Count > 0)
                {
                    string model = dgvscanpcb.Rows[0].Cells["MODEL"].Value.ToString();
                    string pcc = sn.Substring(2, 4);
                    string partnumber = dgvscanpcb.Rows[0].Cells["CUST_PROD_NO"].Value.ToString();
                    txtmodel.Text = model;
                    txtpcc.Text = pcc;
                    txtpart.Text = partnumber;
                }
            }
            catch (Exception sn)
            {
              //  MessageBox.Show(sn.Message) ;
            }
        }

        private void dgvscanpcb_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void check()
        {
            if (  cbxstation.Text != " ")
            {
                txtpcb.Enabled = true;
                txtpcb.Focus();
                if(cbxstation.Text == "REPAIR")
                {
                    cbxSunSta.Visible = true;
                }
                else
                {
                    cbxSunSta.Visible = false;
                }
            }
            else
            {
                txtpcb.Enabled = false;
            }
        }
        private void selectdata()
        {
            try
            {
                string datenow = DateTime.Now.ToString("dd/MM/yyyy HH:mm");
                string dateadd = DateTime.Now.AddHours(4).ToString("dd/MM/yyyy HH:mm");
                string emp = txtempid.Text;
                string pcb = txtpcb.Text;
                string pcc = txtpcc.Text;
                string part = txtpart.Text;
                string md = txtmodel.Text;
                string station = cbxstation.Text;
                string SubStation = cbxSunSta.Text;
                string id = label5.Text;
                string Name = Environment.GetEnvironmentVariable("COMPUTERNAME");
                access2007db db = new access2007db();  //copy mariadbconn.cs มาไหวใน db
                string sql = "INSERT INTO checkstock ";
                sql += "(SN,PCC,MODEL,PN,STATION,SUBSTATION,EMPID,IDeven,ComputerName,DateTimes) VALUES ('" + pcb + "','" + pcc + "',";
                sql += "'"+ md + "','" + part + "','" + station + "','"+ SubStation + "','" + emp + "','" + id + "','" + Name + "','" + datenow + "')";
                db.ExcuteSql(sql);
                countrow++;
                lblcount.Text = countrow.ToString();
              
            }
            catch (Exception eb)
            {
               // MessageBox.Show(eb.Message);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            selectdata();
        }

        private void cbxstation_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                
                selectdata();
            }
        }

        private void cbxstation_SelectedIndexChanged(object sender, EventArgs e)
        {
            check();
        }

    

        private string random()         //-- random Bc
        {
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var stringChars = new char[8];
            var random = new Random();

            for (int i = 0; i < stringChars.Length; i++)
            {
              //  stringChars[i] = chars[random.Next(chars.Length)];
            }
            var finalString = new String(stringChars);
            string ReternData = "WD" + finalString.ToString();
            return ReternData;
            // MessageBox.Show("WD"+finalString);
        }

        private void txtboxid_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Random rd = new Random();
            rd.ShowDialog();
        }
     
        private void button2_Click(object sender, EventArgs e)
        {
            SelectExport();
            GetToCsv();
        }
        private void SelectExport()
        {
            try
            {
                string id = label5.Text;
                string Sql = "SELECT  IDeven FROM checkstock order by DateTimes DESC ";
                access2007db db = new access2007db();
                DataTable dt = new DataTable();
                dt = db.FillDataGrid(Sql);
                dgvfrom.DataSource = dt;
                string Get = "";
                if (dgvfrom.Rows.Count > 1)
                {
                     Get = dgvfrom.Rows[0].Cells["IDeven"].Value.ToString();
                    label5.Text = Get;

                    string ids = label5.Text;
                    string Sqls = "SELECT SN,PCC,MODEL,PN,STATION,EMPID,ComputerName FROM checkstock WHERE IDeven ='" + Get + "' ";
                    //MessageBox.Show(Sqls);
                    access2007db dbs = new access2007db();
                    DataTable dts = new DataTable();
                    dt = db.FillDataGrid(Sqls);
                    dgvfrom.DataSource = dt;
                }
               // MessageBox.Show(Get);
            }
            catch  (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void label5_Click(object sender, EventArgs e)
        {

        }
        int countrow = 0 ;     
        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void txtempid_TextChanged(object sender, EventArgs e)
        {

        }
        private void query()
        {
            try
            {
                access2007db db = new access2007db();
                DataTable dt = new DataTable();
                string sql = "select * from random Where Status = 'on' and Datetimes order by Datetimes DESC ";
                string dtt = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                dt = db.FillDataGrid(sql);
                dgvfrom.DataSource = dt;
                if (dgvfrom.RowCount >= 2)
                {
                    string wait = dgvfrom.Rows[0].Cells["IDeven"].Value.ToString();
                    label5.Text = wait;
                }
                else
                {
                    label5.Text = "No Event";
                }
            }
            catch  (Exception ex)
            {
                //MessageBox.Show("Connection Error !");
            }
        }



        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            query();
        }


        private void GetToCsv()
        {
            //----------  การเก้บ logfile  จาก dgv ไปไว้ใน csv  -------------
            try
            {
                string filename = "" + Application.StartupPath + "\\LogFile.csv"; // ที่อยู๋ logfile
                // Choose whether to write header. Use EnableWithoutHeaderText instead to omit header.
                dgvfrom.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
                // Select all the cells
                dgvfrom.SelectAll();
                // Copy selected cells to DataObject
                DataObject dataObject = dgvfrom.GetClipboardContent();
                // Get the text of the DataObject, and serialize it to a file
                File.WriteAllText(filename, dataObject.GetText(TextDataFormat.CommaSeparatedValue));
            }
            catch { }
        }
            //--------------------------------------------------------------
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void GetUcon()
        {
            UserControl ucon = new PageChart();
            cbxSubSta.Controls.Clear();
            cbxSubSta.Controls.Add(ucon);
        }

        private void tableLayoutPanel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void exportToExcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SelectExport();
            GetToCsv();
        }

        private void genarateIDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Random rd = new Random();
            rd.ShowDialog();
        }
    }
}
