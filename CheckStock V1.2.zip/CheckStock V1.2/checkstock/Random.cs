﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace checkstock
{
    public partial class Random : Form
    {
        public Random()
        {
            InitializeComponent();
        }
        private void Random_Load(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtbox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnxxx_Click(object sender, EventArgs e)
        {
            login();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void login()
        {
            int name = txtempid.Text.Length;
            string pass = "cal-comp74";
            if (name == 7)
            {
                if (pass == txtpassword.Text)
                {
                    txtcreate.Enabled = true;
                    btnoff.Enabled = true;
                    btnon.Enabled = true;
                }
                else
                {
                    txtcreate.Enabled = false;
                    btnoff.Enabled = false;
                    btnon.Enabled = false;
                }
            }
        }
      

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnxxx_Click_1(object sender, EventArgs e)
        {
            insert();
        }
        private void insert()
        {
            try
            {
                string id = txtcreate.Text;
                string Empid = txtempid.Text;
                string dt = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");  // เวลาปัจจุบัน
                string sql = "insert  into random (IDeven , Empid , DateTimes) values ('" + id + "', '" + Empid + "','" + dt + "')";       // ignore ตรวจเช็คข้อมูลซ้ำก่อนที่จะบันทึกข้อมูลลงไป    
                access2007db db = new access2007db();
                db.ExcuteSql(sql);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            query();
        }
        private void query()
        {
            try
            {
                access2007db db = new access2007db();
                DataTable dt = new DataTable();
                string sql = "select * from random Where Status = 'on' and DateTimes order by DateTimes DESC ";
                dt = db.FillDataGrid(sql);
                dgvquery.DataSource = dt;
                if (dgvquery.RowCount >= 2)
                {
                    string wait = dgvquery.Rows[0].Cells["IDeven"].Value.ToString();
                    label3.Text = wait;
                }
                else
                {
                    label3.Text = " No Event";
                }
            }
            catch
            {
            }
        }

        private void txtempid_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnlog_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtcreate_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnlog_Click(object sender, EventArgs e)
        {
            login();
            txtcreate.Focus();
        }
        private void update(int code)
        {
            if (code == 1)
            {
                try
                {
                    access2007db db = new access2007db();
                    DataTable dt = new DataTable();
                    string sql = "update random set Status = 'on'";
                    db.ExcuteSql(sql);
                    dgvquery.DataSource = dt;
                }
                catch
                {

                }
            }
            else
            {
                access2007db db = new access2007db();
                DataTable dt = new DataTable();
                string sql = "update random set Status = 'off'";
                db.ExcuteSql(sql);
                dgvquery.DataSource = dt;
            }
        }
         private void GetToCsv()
        {
            try
            {
                var sb = new StringBuilder();

                var headers = dgvquery.Columns.Cast<DataGridViewColumn>();
                sb.AppendLine(string.Join(",", headers.Select(column => "\"" + column.HeaderText + "\"").ToArray()));

                foreach (DataGridViewRow row in dgvquery.Rows)
                {
                    var cells = row.Cells.Cast<DataGridViewCell>();
                    sb.AppendLine(string.Join(",", cells.Select(cell => "\"" + cell.Value + "\"").ToArray()));
                }
            }
            catch { }
        }
        private void btnon_Click(object sender, EventArgs e)
        {
            update(1);
        }

        private void btnoff_Click(object sender, EventArgs e)
        {
            update(5);
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
